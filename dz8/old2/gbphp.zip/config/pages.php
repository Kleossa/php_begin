<?php
return [
    1 => 'index.php',
    2 => 'users.php',
    3 => 'user.php',
    4 => 'userAdd.php',
];
